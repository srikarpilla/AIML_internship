#include <Servo.h>

// --- Pin Definitions ---
const int TRIG_PIN   = 9;
const int ECHO_PIN   = 10;
const int SERVO_PIN  = 6;
const int LED_PIN    = 13;

// --- Config ---
const int   VEHICLE_THRESHOLD_CM = 20;  // anything closer = vehicle detected
const unsigned long GATE_OPEN_MS = 5000; // gate stays open for 5 seconds

Servo gateServo;

// --- State ---
bool gateOpen         = false;
unsigned long openedAt = 0;

// -------------------------------------------------------
void setup() {
  Serial.begin(9600);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);

  gateServo.attach(SERVO_PIN);
  gateServo.write(0); // Start closed
  digitalWrite(LED_PIN, LOW);

  Serial.println("Smart Gate Ready.");
}

// -------------------------------------------------------
long readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000); // 30ms timeout
  if (duration == 0) return 999; // nothing detected

  return duration * 0.034 / 2;
}

// -------------------------------------------------------
void openGate() {
  Serial.println("Vehicle detected — opening gate.");
  for (int angle = 0; angle <= 90; angle++) {
    gateServo.write(angle);
    digitalWrite(LED_PIN, (angle % 10 < 5) ? HIGH : LOW); // blink while moving
    delay(15);
  }
  digitalWrite(LED_PIN, LOW);
  gateOpen  = true;
  openedAt  = millis();
}

// -------------------------------------------------------
void closeGate() {
  Serial.println("Path clear — closing gate.");
  for (int angle = 90; angle >= 0; angle--) {
    gateServo.write(angle);
    digitalWrite(LED_PIN, (angle % 10 < 5) ? HIGH : LOW); // blink while moving
    delay(15);
  }
  digitalWrite(LED_PIN, LOW);
  gateOpen = false;
}

// -------------------------------------------------------
void loop() {
  long dist = readDistanceCm();
  Serial.print("Distance: ");
  Serial.print(dist);
  Serial.println(" cm");

  if (!gateOpen) {
    // Gate is closed — check for vehicle
    if (dist < VEHICLE_THRESHOLD_CM) {
      openGate();
    }
  } else {
    // Gate is open — wait 5s, then close only if path is clear
    unsigned long elapsed = millis() - openedAt;
    if (elapsed >= GATE_OPEN_MS) {
      if (dist >= VEHICLE_THRESHOLD_CM) {
        closeGate();
      } else {
        Serial.println("Path blocked — keeping gate open.");
      }
    }
  }

  delay(200);
}
